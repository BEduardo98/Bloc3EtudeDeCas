const request = require("supertest");
const { app } = require("../server");
const mockingoose = require("mockingoose");
const Article = require("../api/articles/articles.schema");
const jwt = require("jsonwebtoken");
const config = require("../config");

describe("tester Méthodes Articles", () => {
  const USER_ID = "fake";
  const USER_MOCK_DATA = [
    {
      _id: USER_ID,
      name: "ssksk",
      email: "esq@gmail.com",
      password: "$2b$10$iGEVyBX56TNGAFGztqk9Zun3OBZy6q.N59B.ORR6QCKgaJh2cUcxW",
    },
  ];
  const ARTICLE_MOCK_DATA = [
    {
      title: "Le fromage est trop bon",
      content: "la lala llall all al aall aal la l laal la lall all al la",
      user: {
        _id: USER_ID,
      },
      status: "published",
    },
    {
      title: "J'adore le pain",
      content: "Le pain est délicieux avec du fromage",
      user: {
        _id: USER_ID,
      },
      status: "draft",
    },
    {
      title: "La vie à Paris",
      content: "Paris est une ville magnifique avec beaucoup de fromage",
      user: {
        _id: USER_ID,
      },
      status: "published",
    },
  ];

  beforeEach(() => {
    token = jwt.sign({ userId: USER_ID }, config.secretJwtToken);
    mockingoose(Article).toReturn(ARTICLE_MOCK_DATA, "save");
    mockingoose(Article).toReturn(ARTICLE_MOCK_DATA[1], "findOne");
    mockingoose(Article).toReturn(ARTICLE_MOCK_DATA[2], "findOneAndUpdate");
    mockingoose(Article).toReturn(ARTICLE_MOCK_DATA[3], "findOneAndDelete");
  });

  test("[Articles] Create Article", async () => {
    const newArticle = {
      title: "Nouvel article",
      content: "Ceci est un nouvel article",
      user: "UserTest",
      status: "draft",
    };
    const res = await request(app).post("/api/articles").send(newArticle).set("x-access-token", token);
    expect(res.status).toBe(201);
    expect(res.body.title).toBe(newArticle.title);
  });
  test("[Articles] Update Article", async () => {
    const updatedArticle = {
      title: "Article mis à jour",
      content: "Ceci est un article mis à jour",
    };
    const res = await request(app).put(`/api/articles/${ARTICLE_MOCK_DATA[1]._id}`).send(updatedArticle).set("x-access-token", token);
    expect(res.status).toBe(200);
    expect(res.body.title).toBe(updatedArticle.title);
  });
  test("[Articles] Delete Article", async () => {
    const res = await request(app).delete(`/api/articles/${ARTICLE_MOCK_DATA[1]._id}`).set("x-access-token", token);
    expect(res.status).toBe(204);
  });
});
